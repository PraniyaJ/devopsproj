import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

const Dashboard = () => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    // Check if user is authenticated
    const token = localStorage.getItem('authToken');
    const userData = localStorage.getItem('user');

    if (!token) {
      navigate('/login');
      return;
    }

    try {
      const parsedUser = JSON.parse(userData);
      setUser(parsedUser);
    } catch (err) {
      console.error('Error parsing user data:', err);
      handleLogout();
    }

    // Verify token with backend (optional)
    verifyToken(token);
  }, [navigate]);

  const verifyToken = async (token) => {
    try {
      const response = await fetch('http://localhost:5000/api/dashboard', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });

      if (!response.ok) {
        throw new Error('Token invalid');
      }

      setLoading(false);
    } catch (error) {
      console.error('Token verification failed:', error);
      setError('Session expired. Please log in again.');
      handleLogout();
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('authToken');
    localStorage.removeItem('user');
    navigate('/login');
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-600 via-blue-600 to-blue-800 flex items-center justify-center">
        <div className="text-white text-xl">Loading...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-600 via-blue-600 to-blue-800">
      {/* Header */}
      <nav className="bg-white/10 backdrop-blur-md border-b border-white/20 px-6 py-4">
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          <div className="text-white text-xl font-semibold">
            MyApp Dashboard
          </div>
          <button 
            onClick={handleLogout}
            className="bg-red-500/20 hover:bg-red-500/30 text-white px-6 py-2 rounded-full transition-all duration-300 border border-red-500/30 hover:border-red-500/50"
          >
            Logout
          </button>
        </div>
      </nav>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-6 py-8">
        <div className="bg-white/10 backdrop-blur-md rounded-2xl border border-white/20 p-8 shadow-2xl">
          <div className="text-center text-white mb-8">
            <h1 className="text-4xl font-bold mb-4 font-poppins">
              Welcome to Your Dashboard!
            </h1>
            <p className="text-xl opacity-80">
              Hello, {user?.name}!
            </p>
          </div>

          {error && (
            <div className="mb-6 p-4 bg-red-500/20 border border-red-500/50 rounded-lg text-white">
              {error}
            </div>
          )}

          {/* User Info Cards */}
          <div className="grid md:grid-cols-2 gap-6 mb-8">
            <div className="bg-white/5 border border-white/10 rounded-xl p-6">
              <h3 className="text-white text-lg font-semibold mb-2">Profile Information</h3>
              <div className="text-white/80">
                <p><strong>Name:</strong> {user?.name}</p>
                <p><strong>Email:</strong> {user?.email}</p>
                <p><strong>User ID:</strong> {user?.id}</p>
              </div>
            </div>

            <div className="bg-white/5 border border-white/10 rounded-xl p-6">
              <h3 className="text-white text-lg font-semibold mb-2">Quick Stats</h3>
              <div className="text-white/80">
                <p><strong>Account Status:</strong> Active</p>
                <p><strong>Login Status:</strong> Online</p>
                <p><strong>Last Login:</strong> Just now</p>
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="text-center">
            <div className="bg-white/5 border border-white/10 rounded-xl p-6">
              <h3 className="text-white text-lg font-semibold mb-4">Dashboard Actions</h3>
              <div className="flex flex-wrap gap-4 justify-center">
                <button className="bg-blue-500/20 hover:bg-blue-500/30 text-white px-6 py-3 rounded-full transition-all duration-300 border border-blue-500/30 hover:border-blue-500/50">
                  View Profile
                </button>
                <button className="bg-green-500/20 hover:bg-green-500/30 text-white px-6 py-3 rounded-full transition-all duration-300 border border-green-500/30 hover:border-green-500/50">
                  Settings
                </button>
                <button className="bg-purple-500/20 hover:bg-purple-500/30 text-white px-6 py-3 rounded-full transition-all duration-300 border border-purple-500/30 hover:border-purple-500/50">
                  Help
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;